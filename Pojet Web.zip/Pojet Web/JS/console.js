function verifier() {
    var civilité = document.forms["RegForm"]["sujet"];
    var name = document.forms["RegForm"]["Nom"];
    var lname = document.forms["RegForm"]["prenom"];
    var email = document.forms["RegForm"]["Email"];
    var password = document.forms["RegForm"]["Mot de passe"];
    var phone = document.forms["RegForm"]["Téléphone"];
    var dateb = document.forms["RegForm"]["date"];
    
    console. log( dateb.value.substring(0,4)) ;
    if ( dateb.value.substring(0,4) < 1900) {

        alert("Date de naissance invalide.");
        name.focus();
        return false;
      }
    if (name.value == "") {
      alert("Mettez votre nom.");
      name.focus();
      return false;
    }
    if (lname.value == "") {
        alert("Mettez votre prénom.");
        name.focus();
        return false;
      }
    if (email.value == "") {
      alert("Mettez une adresse email valide.");
      email.focus();
      return false;
    }
    if (email.value.indexOf("@", 0) < 0) {
      alert("Mettez une adresse email valide.");
      email.focus();
      return false;
    }
    if (email.value.indexOf(".", 0) < 0) {
      alert("Mettez une adresse email valide.");
      email.focus();
      return false;
    }
    if (phone.value == "") {
      alert("Mettez votre numéro de téléphone.");
      phone.focus();
      return false;
    }
    if (password.value == "") {
      alert("Saisissez votre mot de passe");
      password.focus();
      return false;
    }
    if (what.selectedIndex < 1) {
      alert("Mettez votre cours.");
      what.focus();
      return false;
    }
   
    return true;
  }
   